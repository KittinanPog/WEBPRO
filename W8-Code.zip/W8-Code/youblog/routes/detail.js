const express = require('express')
const router = express.Router()
var article = require('../article-db')


router.get('/', function (req, res) {
    res.send('ไม่พบหน้าที่ต้องการ')
})

router.get('/:id', (req, res) => {
    var data = { title: 'YOU BLOG', article: article[req.params.id-1]}
    res.render('detail', data)

})

module.exports = router