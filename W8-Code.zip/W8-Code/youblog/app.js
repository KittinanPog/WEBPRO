
const express = require('express')
const path = require('path')
const app = express()

// ดึงข้อมูล json มาเก็บไว้ในตัวแปร

const article = require('./article-db')

// Setup ejs
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Setup static path
app.use(express.static(path.join(__dirname, 'public')))

// Config Router
const indexRouter = require('./routes/index')
const detailRouter = require('./routes/detail')

app.use('/', indexRouter)
app.use('/detail', detailRouter)
app.listen(3000, () => {
  console.log('Start server at port 3000.')
})