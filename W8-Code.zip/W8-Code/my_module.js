const NAME = 'Bundit'

const add = (a, b) => a + b
const substract = (a, b) => a - b

// module.exports.NAME = NAME
// module.exports.add = add
// module.exports.substract = substract

// Shortcut -> exports = module.exports
exports.NAME = NAME
exports.add = add
exports.substract = substract

