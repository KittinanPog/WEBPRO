const express = require("express");

const router = express.Router();
const pool = require("../config");

// Get comment
router.get('/:blogId/comments', function(req, res, next){

});

// Create new comment
router.post('/:blogId/comments', async function(req, res, next){
    try{
     const [rows, fields] = await pool.query("INSERT INTO comments(blog_id,comment,comments.like) VALUES(?,?,?)", [
      req.params.blogId,'new comment',0,
    ]);
    

        return res.json({
          message:"A new comment is add by"+req.params.blogId
    })
   
    }catch (err) {
        return next(err);
      }
    
});

// Update comment
router.put('/comments/:commentId', async function(req, res, next){
    try{
        const [rows1, fields1] = await pool.query("UPDATE comments SET comments.comment=?,comments.like=?,comments.comment_date=?,comments.blog_id=? WHERE comments.id =?", [
         'edit comment',0,"2021-12-31",1,req.params.commentId
       ]);
       const [rows2, fields2] = await pool.query("SELECT * FROM comments WHERE id=?", [
        req.params.commentId,
      ]);
         return res.json({
          message:"Comment ID" +req.params.commentId+"is updated.",
          comment:rows2.id
    })
           // let comments = rows.coments
      
       }catch (err) {
           return next(err);
         }
       
});

// Delete comment
router.delete('/comments/:commentId', async function(req, res, next){
  try{
    const [rows, fields] =  await pool.query("DELETE FROM comments WHERE id =?", [
     req.params.commentId
   ]);

     return res.json({
      message:"Comment ID" +req.params.commentId+"is deleted."
})
   }catch (err) {
       return next(err);
     }
});

// Delete comment
router.put('/comments/addlike/:commentId', async function(req, res, next){
  try {
    const [rows, fields] = await pool.query("SELECT * FROM comments WHERE id=?", [
      req.params.commentId,
    ]);
    console.log('Selected blogs =', rows)
    let likeNum = rows[0].like
    console.log('Like num =', likeNum)
    likeNum += 1
    const [rows2, fields2] = await pool.query("UPDATE comments SET comments.like = ? WHERE comments.id=?", [
      likeNum, req.params.commentId,
    ]);
    
    return res.json({
      blogId: rows[0].blog_id,
      commentId: rows[0].id,
      likeNum: rows[0].like+1,
})
  } catch (err) {
    return next(err);
  }
});


exports.router = router